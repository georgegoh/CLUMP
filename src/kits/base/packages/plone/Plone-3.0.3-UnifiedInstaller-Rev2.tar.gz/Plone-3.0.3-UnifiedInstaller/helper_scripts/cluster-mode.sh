############################################################################
# Unified Plone installer build script
# ZEO Cluster builder.
# Author: Kamal Gill (kamalgill at mac.com)
# Adapted for Plone 3 by Steve McMahon (steve at dcn.org)
############################################################################


PRODUCTS_HOME=$ZEOCLUSTER_HOME/Products
INSTANCE_LIB_HOME=$ZEOCLUSTER_HOME/lib
EXTENSIONS_HOME=$ZEOCLUSTER_HOME/Extensions
ZEOSERVER_HOME=$ZEOCLUSTER_HOME/server
ZEOCLIENT1_HOME=$ZEOCLUSTER_HOME/client1
ZEOCLIENT2_HOME=$ZEOCLUSTER_HOME/client2
PWFILE=$ZEOCLUSTER_HOME/adminPassword.txt
ZEO_STARTUP_SCRIPT=$ZEOCLUSTER_HOME/bin/startcluster.sh
ZEO_SHUTDOWN_SCRIPT=$ZEOCLUSTER_HOME/bin/shutdowncluster.sh
ZEO_RESTART_SCRIPT=$ZEOCLUSTER_HOME/bin/restartcluster.sh
ZEO_STATUS_SCRIPT=$ZEOCLUSTER_HOME/bin/clusterstatus.sh
RECEIPTS_HOME=$PLONE_HOME/receipts

####################
# Create ZEO Cluster
echo "Creating Zope Enterprise Cluster ..."
echo "Creating ZEO server on port 8100 ..."
$PLONE_HOME/bin/mkzeoinstance.py $ZEOSERVER_HOME 8100
echo "Creating ZEO client1 ..."
$PLONE_HOME/bin/mkzopeinstance.py --dir=$ZEOCLIENT1_HOME --user=admin:$PASSWORD
echo "Creating ZEO client2 ..."
$PLONE_HOME/bin/mkzopeinstance.py --dir=$ZEOCLIENT2_HOME --user=admin:$PASSWORD


#####################################
# If root install, set effective-user in etc/zope.conf
if [ $ROOT_INSTALL -eq 1 ]
then
	echo "Setting user in ZEO server"
	mv $ZEOSERVER_HOME/etc/zeo.conf $ZEOSERVER_HOME/etc/zeo.conf.tmp
	cat $ZEOSERVER_HOME/etc/zeo.conf.tmp | sed 's/^.*#.*user.*$/  user plone/g' > $ZEOSERVER_HOME/etc/zeo.conf 
	
	echo "Setting user in ZEO client1"
	mv $ZEOCLIENT1_HOME/etc/zope.conf $ZEOCLIENT1_HOME/etc/zope.conf.tmp
	cat $ZEOCLIENT1_HOME/etc/zope.conf.tmp | sed 's/^.*#.*effective-user.*chrism.*$/effective-user plone/g' > $ZEOCLIENT1_HOME/etc/zope.conf
	rm $ZEOCLIENT1_HOME/etc/zope.conf.tmp

	echo "Setting user in ZEO client2"
	mv $ZEOCLIENT2_HOME/etc/zope.conf $ZEOCLIENT2_HOME/etc/zope.conf.tmp
	cat $ZEOCLIENT2_HOME/etc/zope.conf.tmp | sed 's/^.*#.*effective-user.*chrism.*$/effective-user plone/g;' > $ZEOCLIENT2_HOME/etc/zope.conf
	rm $ZEOCLIENT2_HOME/etc/zope.conf.tmp
fi


# set ZEO client2 http port to 8081
mv $ZEOCLIENT2_HOME/etc/zope.conf $ZEOCLIENT2_HOME/etc/zope.conf.tmp
cat $ZEOCLIENT2_HOME/etc/zope.conf.tmp | sed 's/^ *address.*8080.*$/  address 8081/g' > $ZEOCLIENT2_HOME/etc/zope.conf
rm $ZEOCLIENT2_HOME/etc/zope.conf.tmp


#########################################################
# Pre-initialize log file and set appropriate permissions
# (if unset, ZEO server refuses to start as an unprivileged user via 'zeoctl start')
touch $ZEOSERVER_HOME/log/zeo.log
chmod 775 $ZEOSERVER_HOME/log/zeo.log
# also set user for client log and var directories
if [ $ROOT_INSTALL -eq 1 ]
then
	find $ZEOCLUSTER_HOME -type d -name var -exec chown -R plone {} \;
	find $ZEOCLUSTER_HOME -type d -name log -exec chown -R plone {} \;
fi


###############################################################
# Extract and move Plone tarball to Products folder of Instance
echo "Extracting Plone tarball ..."
cp $PKG/$PLONE_TB $PLONE_HOME/$PLONE_TB
cd $PLONE_HOME
$GNU_TAR --bzip2 -xf ./$PLONE_TB 
rm $PLONE_HOME/$PLONE_TB
# Products subdirectory becomes Products
mv $PLONE_HOME/$PLONE_DIR/Products $PRODUCTS_HOME
# lib subdirectory contents moved to lib/python
mv $PLONE_HOME/$PLONE_DIR/lib $INSTANCE_LIB_HOME
rm -r $PLONE_HOME/$PLONE_DIR

# set permissions that will allow plone user to write .pyc files
if [ $ROOT_INSTALL -eq 1 ]
then
	chown -R plone $PRODUCTS_HOME
	chown -R plone $INSTANCE_LIB_HOME
	# set group also
	if [ "x$PGROUP" != "x" ]
	then
		chgrp -R $PGROUP $PRODUCTS_HOME
		chgrp -R $PGROUP $INSTANCE_LIB_HOME
	fi
fi
chmod -R 755 $PRODUCTS_HOME
chmod -R 755 $INSTANCE_LIB_HOME

cd $PKG



###############################################
# Create common Products, lib, Extensions folder for ZEO cluster
echo "Configuring shared Products directory ..."
# remove Products directories to set up symlinks
rm -rf $ZEOCLIENT1_HOME/Products
rm -rf $ZEOCLIENT2_HOME/Products
# set up symlinks for shared Products folder
ln -s $PRODUCTS_HOME $ZEOCLIENT1_HOME/Products
ln -s $PRODUCTS_HOME $ZEOCLIENT2_HOME/Products
echo "Configuring shared lib directory ..."
# remove lib directories to set up symlinks
rm -rf $ZEOCLIENT1_HOME/lib
rm -rf $ZEOCLIENT2_HOME/lib
# set up symlinks for shared instance lib folder
ln -s $INSTANCE_LIB_HOME $ZEOCLIENT1_HOME/lib
ln -s $INSTANCE_LIB_HOME $ZEOCLIENT2_HOME/lib
echo "Configuring shared Extensions directory ..."
# move/remove Extensions directories & set up symlinks
mv $ZEOCLIENT1_HOME/Extensions $EXTENSIONS_HOME
rm -rf $ZEOCLIENT2_HOME/Extensions
# set up symlinks for shared Extensions folder
ln -s $EXTENSIONS_HOME $ZEOCLIENT1_HOME/Extensions
ln -s $EXTENSIONS_HOME $ZEOCLIENT2_HOME/Extensions


########################
# Write password to file
echo "Writing random password to file ..."
touch $PWFILE
# Write admin password and startup/shutdown info to password file
echo "Use the account information below to log into the Zope Management Interface" >> "$PWFILE"
echo "The account has full 'Manager' privileges." >> "$PWFILE"
echo " " >> "$PWFILE"
echo "  Username: admin" >> "$PWFILE"
echo "  Password: $PASSWORD" >> "$PWFILE"
echo " " >> "$PWFILE"
echo "Before you start Plone, you should review the settings in:" >> "$PWFILE"
echo " " >> "$PWFILE"
echo "  $ZEOSERVER_HOME/etc/zeo.conf" >> "$PWFILE"
echo " and" >> "$PWFILE"
echo "  $ZEOCLIENT1_HOME/etc/zope.conf" >> "$PWFILE"
echo " and" >> "$PWFILE"
echo "  $ZEOCLIENT2_HOME/etc/zope.conf" >> "$PWFILE"
echo " " >> "$PWFILE"
echo "Adjust the ports Plone uses before starting the site, if necessary" >> "$PWFILE"
echo " " >> "$PWFILE"
echo "To start Plone, issue the following command in a Terminal window:" >> "$PWFILE"
echo " " >> "$PWFILE"
echo "  $SUDO $ZEO_STARTUP_SCRIPT" >> "$PWFILE"
echo " " >> "$PWFILE"
echo "To stop Plone, issue the following command in a Terminal window:" >> "$PWFILE"
echo " " >> "$PWFILE"
echo "  $SUDO $ZEO_SHUTDOWN_SCRIPT" >> "$PWFILE"
echo " " >> "$PWFILE"



#########################################
# Configure ZEO clients to use ZEO server
echo "Configuring client1 to connect to server"
mv $ZEOCLIENT1_HOME/etc/zope.conf $ZEOCLIENT1_HOME/etc/zope.conf.tmp
cat $ZEOCLIENT1_HOME/etc/zope.conf.tmp | sed 's/^.*<filestorage>.*$/  <zeoclient>\
    server localhost:8100\
    storage 1\
    name zeostorage\
    var \$INSTANCE\/var/g; s/^.*<\/filestorage>.*$/  <\/zeoclient>/g; s/^.*path.*\$INSTANCE\/var\/Data.fs.*$//g' > $ZEOCLIENT1_HOME/etc/zope.conf
rm $ZEOCLIENT1_HOME/etc/zope.conf.tmp

echo "Configuring client2 to connect to server"
mv $ZEOCLIENT2_HOME/etc/zope.conf $ZEOCLIENT2_HOME/etc/zope.conf.tmp
cat $ZEOCLIENT2_HOME/etc/zope.conf.tmp | sed 's/^.*<filestorage>.*$/  <zeoclient>\
    server localhost:8100\
    storage 1\
    name zeostorage\
    var \$INSTANCE\/var/g; s/^.*<\/filestorage>.*$/  <\/zeoclient>/g; s/^.*path.*\$INSTANCE\/var\/Data.fs.*$//g' > $ZEOCLIENT2_HOME/etc/zope.conf
rm $ZEOCLIENT2_HOME/etc/zope.conf.tmp


echo "Changing ZEO socket location from etc to var"
mv $ZEOSERVER_HOME/etc/zeo.conf $ZEOSERVER_HOME/etc/zeo.conf.tmp
cat $ZEOSERVER_HOME/etc/zeo.conf.tmp | sed 's/^.*socket-name \$INSTANCE\/etc\/zeo.zdsock.*$/  socket-name $INSTANCE\/var\/zeo.zdsock/g' > $ZEOSERVER_HOME/etc/zeo.conf
rm $ZEOSERVER_HOME/etc/zeo.conf.tmp



####################################################
# Write ZEO startup/shutdown/restart scripts to file
# Create bin folder in zeocluster
mkdir $ZEOCLUSTER_HOME/bin

# copy over the zopectl run scripts we'll use for Data.fs initialization
cp $CWD/$HSCRIPTS_DIR/mkPloneSite.py $ZEOCLUSTER_HOME/bin
touch $ZEOCLUSTER_HOME/bin/empty.py


# Write startup script
echo "Writing startup script to file ..."
touch $ZEO_STARTUP_SCRIPT
echo "#!/bin/sh" >> "$ZEO_STARTUP_SCRIPT"
echo "#" >> "$ZEO_STARTUP_SCRIPT"
echo "# ZEO cluster startup script" >> "$ZEO_STARTUP_SCRIPT"
echo "#" >> "$ZEO_STARTUP_SCRIPT"
echo "if [ -e $ZEOSERVER_HOME/var/Data.fs ]" >> "$ZEO_STARTUP_SCRIPT"
echo "then" >> "$ZEO_STARTUP_SCRIPT"
echo "	FIRST_TIME=\"N\"" >> "$ZEO_STARTUP_SCRIPT"
echo "else" >> "$ZEO_STARTUP_SCRIPT"
echo "	FIRST_TIME=\"Y\"" >> "$ZEO_STARTUP_SCRIPT"
echo "fi" >> "$ZEO_STARTUP_SCRIPT"
echo "echo 'Starting ZEO server...'" >> "$ZEO_STARTUP_SCRIPT"
echo "$ZEOSERVER_HOME/bin/zeoctl start" >> "$ZEO_STARTUP_SCRIPT"
echo "sleep 1" >> "$ZEO_STARTUP_SCRIPT"
echo "if [ \$FIRST_TIME = \"Y\" ]" >> "$ZEO_STARTUP_SCRIPT"
echo "then" >> "$ZEO_STARTUP_SCRIPT"
echo "	echo 'This is the first start of this instance.'" >> "$ZEO_STARTUP_SCRIPT"
echo "	echo 'Creating Data.fs and a Plone site.'" >> "$ZEO_STARTUP_SCRIPT"
echo "	echo 'We only need to do this once, but it takes some time.'" >> "$ZEO_STARTUP_SCRIPT"
# Code below was for the ZEO First-Start Bug. Now fixed.
# echo "	echo 'Creating Data.fs...'" >> "$ZEO_STARTUP_SCRIPT"
# echo "	$ZEOCLIENT1_HOME/bin/zopectl run $ZEOCLUSTER_HOME/bin/empty.py 2> $ZEOCLIENT1_HOME/log/firststart.log" >> "$ZEO_STARTUP_SCRIPT"
# echo "	sleep 1" >> "$ZEO_STARTUP_SCRIPT"
# echo "	echo 'Restarting ZEO server...'" >> "$ZEO_STARTUP_SCRIPT"
# echo "	$ZEOSERVER_HOME/bin/zeoctl stop" >> "$ZEO_STARTUP_SCRIPT"
# echo "	sleep 10" >> "$ZEO_STARTUP_SCRIPT"
# echo "	$ZEOSERVER_HOME/bin/zeoctl start" >> "$ZEO_STARTUP_SCRIPT"
# echo "	sleep 1" >> "$ZEO_STARTUP_SCRIPT"
echo "	echo 'Creating Plone site at /Plone in ZODB...'" >> "$ZEO_STARTUP_SCRIPT"
echo "	$ZEOCLIENT1_HOME/bin/zopectl run $ZEOCLUSTER_HOME/bin/mkPloneSite.py 2>> $ZEOCLIENT1_HOME/log/firststart.log" >> "$ZEO_STARTUP_SCRIPT"
echo "	sleep 1" >> "$ZEO_STARTUP_SCRIPT"
echo "	$ZEOCLIENT1_HOME/bin/zopectl start" >> "$ZEO_STARTUP_SCRIPT"
echo "else" >> "$ZEO_STARTUP_SCRIPT"
echo "	echo 'Starting ZEO client1...'" >> "$ZEO_STARTUP_SCRIPT"
echo "	$ZEOCLIENT1_HOME/bin/zopectl start" >> "$ZEO_STARTUP_SCRIPT"
echo "fi" >> "$ZEO_STARTUP_SCRIPT"
echo "sleep 1" >> "$ZEO_STARTUP_SCRIPT"
echo "echo 'Starting ZEO client2...'" >> "$ZEO_STARTUP_SCRIPT"
echo "$ZEOCLIENT2_HOME/bin/zopectl start" >> "$ZEO_STARTUP_SCRIPT"

# Write shutdown script
echo "Writing shutdown script to file ..."
touch $ZEO_SHUTDOWN_SCRIPT
echo "#!/bin/sh" >> "$ZEO_SHUTDOWN_SCRIPT"
echo "#" >> "$ZEO_SHUTDOWN_SCRIPT"
echo "# ZEO cluster shutdown script" >> "$ZEO_SHUTDOWN_SCRIPT"
echo "#" >> "$ZEO_SHUTDOWN_SCRIPT"
echo "echo 'Stopping ZEO server...'" >> "$ZEO_SHUTDOWN_SCRIPT"
echo "$ZEOSERVER_HOME/bin/zeoctl stop" >> "$ZEO_SHUTDOWN_SCRIPT"
echo "sleep 1" >> "$ZEO_SHUTDOWN_SCRIPT"
echo "echo 'Stopping ZEO client1...'" >> "$ZEO_SHUTDOWN_SCRIPT"
echo "$ZEOCLIENT1_HOME/bin/zopectl stop" >> "$ZEO_SHUTDOWN_SCRIPT"
echo "sleep 1" >> "$ZEO_SHUTDOWN_SCRIPT"
echo "echo 'Stopping ZEO client2...'" >> "$ZEO_SHUTDOWN_SCRIPT"
echo "$ZEOCLIENT2_HOME/bin/zopectl stop" >> "$ZEO_SHUTDOWN_SCRIPT"

# Write restart script
echo "Writing restart script to file ..."
touch $ZEO_RESTART_SCRIPT
echo "#!/bin/sh" >> "$ZEO_RESTART_SCRIPT"
echo "#" >> "$ZEO_RESTART_SCRIPT"
echo "# ZEO cluster restart script" >> "$ZEO_RESTART_SCRIPT"
echo "#" >> "$ZEO_RESTART_SCRIPT"
echo "echo 'Restarting ZEO server...'" >> "$ZEO_RESTART_SCRIPT"
echo "$ZEOSERVER_HOME/bin/zeoctl restart" >> "$ZEO_RESTART_SCRIPT"
echo "sleep 1" >> "$ZEO_RESTART_SCRIPT"
echo "echo 'Restarting ZEO client1...'" >> "$ZEO_RESTART_SCRIPT"
echo "$ZEOCLIENT1_HOME/bin/zopectl restart" >> "$ZEO_RESTART_SCRIPT"
echo "sleep 1" >> "$ZEO_RESTART_SCRIPT"
echo "echo 'Restarting ZEO client2...'" >> "$ZEO_RESTART_SCRIPT"
echo "$ZEOCLIENT2_HOME/bin/zopectl restart" >> "$ZEO_RESTART_SCRIPT"

# Write status script
touch $ZEO_STATUS_SCRIPT
echo "Writing status script to file ..."
echo '#!/bin/sh' >> "$ZEO_STATUS_SCRIPT"
echo '# Cluster Status Discovery' >> "$ZEO_STATUS_SCRIPT"
echo '' >> "$ZEO_STATUS_SCRIPT"
echo 'zeoclients="client1 client2"' >> "$ZEO_STATUS_SCRIPT"
echo '' >> "$ZEO_STATUS_SCRIPT"
echo "clusterpath=$ZEOCLUSTER_HOME" >> "$ZEO_STATUS_SCRIPT"
echo '' >> "$ZEO_STATUS_SCRIPT"
echo 'if [ ! -w ${clusterpath}/server/var ]; then' >> "$ZEO_STATUS_SCRIPT"
echo '    echo "You lack the rights necessary to run this script;\nTry sudo $0"' >> "$ZEO_STATUS_SCRIPT"
echo '    exit 1' >> "$ZEO_STATUS_SCRIPT"
echo 'fi' >> "$ZEO_STATUS_SCRIPT"
echo '' >> "$ZEO_STATUS_SCRIPT"
echo 'echo "ZEO Server:"' >> "$ZEO_STATUS_SCRIPT"
echo '${clusterpath}/server/bin/zeoctl status' >> "$ZEO_STATUS_SCRIPT"
echo 'for client in $zeoclients' >> "$ZEO_STATUS_SCRIPT"
echo 'do' >> "$ZEO_STATUS_SCRIPT"
echo '    echo "Zope Client:" $client' >> "$ZEO_STATUS_SCRIPT"
echo '    ${clusterpath}/${client}/bin/zopectl status' >> "$ZEO_STATUS_SCRIPT"
echo 'done' >> "$ZEO_STATUS_SCRIPT"


###########################################
# Set appropriate ownership and permissions
echo "Setting some more file ownership and permissions ..."
chmod 600 "$PWFILE"
chmod -R 755 $ZEOCLUSTER_HOME/bin

