#!/bin/sh

case "$1" in
start)
        echo -n " Starting Zope"
        /opt/Plone-3.0/zinstance/bin/zopectl start
        ;;
stop)
        echo -n " Stopping Zope"
        /opt/Plone-3.0/zinstance/bin/zopectl stop
        ;;
restart)
        echo -n " Restarting Zope"
        /opt/Plone-3.0/zinstance/bin/zopectl restart
        ;;
status)
        echo -n " Zope Status"
        /opt/Plone-3.0/zinstance/bin/zopectl status
        ;;
*)
        echo "Usage: `basename $0` {start|stop|restart|status}" >&2
        ;;
esac

exit 0
