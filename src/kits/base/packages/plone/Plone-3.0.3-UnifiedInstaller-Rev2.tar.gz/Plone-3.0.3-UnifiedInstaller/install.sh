#!/bin/sh
#
# Unified Plone installer build script
# Author: Kamal Gill (kamalgill at mac.com)
# Adapted for Plone 3 by Steve McMahon (steve at dcn.org)
#
#

# Usage: sudo ./install.sh options
# or, for non-root install: ./install.sh options
#
# Options:
#
#  standalone - install standalone zope instance
#  zeo        - install zeo cluster
#
# If PLONE_HOME has already been built, you may also use:
#  ci	      - install cluster instance only
#  si         - install standalone instance only

#################################################
# Commonly configured options:

# Path options for Root install
#
# Path for install of Python/Zope/Plone
PLONE_HOME=/opt/Plone-3.0.3
# if we create a ZEO cluster, it will go here:
ZEOCLUSTER_HOME=$PLONE_HOME/zeocluster
# a stand-alone (non-zeo) instance will go here:
RINSTANCE_HOME=$PLONE_HOME/zinstance

# Path options for Non-Root install
#
# Path for install of Python/Zope/Plone
LOCAL_HOME=$HOME/Plone-3.0.3
# if we create a ZEO cluster, it will go here:
LOCAL_ZEOCLUSTER_HOME=$LOCAL_HOME/zeocluster
# a stand-alone (non-zeo) instance will go here:
LOCAL_RINSTANCE_HOME=$LOCAL_HOME/zinstance

# Locations of required build tools.
# If 'which' won't find the right tool, edit below to specify the full pathname.
GCC=`which gcc`
GPP=`which g++`
GNU_MAKE=`which make`
# tar must support -z and --bzip2 flags
GNU_TAR=`which tar`

TAR_BZIP2_FLAG="--bzip2"
# if --bzip2 doesn't work on your platform, uncomment the following to try -j
#TAR_BZIP2_FLAG="-j"

# This install requires the zlib and libjpeg libraries, which are
# usually installed as system libraries.
# Set the options below to
#   auto -   to have this program determine whether or not you need the
#            library installed, and where.
#   global - to force install to /usr/local/ (requires root)
#   local  - to force install to $PLONE_HOME (or $LOCAL_HOME) for static link
#   no     - to force no install 
INSTALL_ZLIB=auto
INSTALL_JPEG=auto

# End of commonly configured options.
#################################################


if [ `whoami` = "root" ]
then
	ROOT_INSTALL=1
	SUDO="sudo"
else
	ROOT_INSTALL=0
	SUDO=""
	# set paths to local versions
	PLONE_HOME=$LOCAL_HOME
	ZEOCLUSTER_HOME=$LOCAL_ZEOCLUSTER_HOME
	RINSTANCE_HOME=$LOCAL_RINSTANCE_HOME
fi


# More paths
PY_HOME=$PLONE_HOME/Python-2.4.4
LOCAL_HOME=$PY_HOME
PY=$PY_HOME/bin/python
SITE_PACKAGES=$PY_HOME/lib/python2.4/site-packages

 
# This script should be run from the directory with the tarballs
# Include the following tarballs in the packages/ directory in the bundle...
PYTHON_TB=Python-2.4.4.tar.bz2
PYTHON_DIR=Python-2.4.4
JPEG_TB=jpegsrc.v6b.tar.bz2
JPEG_DIR=jpeg-6b
ZLIB_TB=zlib-1.2.3.tar.bz2
ZLIB_DIR=zlib-1.2.3
PIL_TB=Imaging-1.1.6.tar.bz2
PIL_DIR=Imaging-1.1.6
ZOPE_TB=Zope-2.10.5-final.tar.bz2
ZOPE_DIR=Zope-2.10.5-final
PLONE_TB=Plone-3.0.3.tar.bz2
PLONE_DIR=Plone-3.0.3
HSCRIPTS_DIR=helper_scripts
ETREE_TB=elementtree-1.2.6-20050316.tar.gz
ETREE_DIR=elementtree-1.2.6-20050316
SETUP_TB=setuptools-0.6c7-py2.4.tgz
PYLIBXML2_TB=libxml2-python-2.6.21.tar.gz
PYLIBXML2_DIR=libxml2-python-2.6.21
PYOID_TB=python-openid-2.0.1.tar.bz2
PYOID_DIR=python-openid-2.0.1


# Capture current working directory for build script
PWD=`pwd`
CWD="$PWD"

PACKAGES_DIR=packages
PKG=$CWD/$PACKAGES_DIR

# Make sure CDPATH doesn't spoil cd
unset CDPATH


# Abort install if this script is not run from within it's parent folder
if [ ! -x $PACKAGES_DIR ] || [ ! -x $HSCRIPTS_DIR ]

then
	echo ""
	echo "This install script must be run within the installer's top directory."
	echo "That directory should contain $PACKAGES_DIR and $HSCRIPTS_DIR subdirectories."
	echo ""
	exit 1
fi


#########################################################
# Pick up zeo or standalone option from command line
POST_ONLY=0
INSTALL_ZEO=0
INSTALL_STANDALONE=0
case $1 in
zeo | cluster | zeocluster )
        echo ZEO Cluster Install selected
	INSTALL_ZEO=1
        ;;
standalone | nozeo | stand-alone | sa )
        echo Stand-Alone Zope Instance selected
	INSTALL_STANDALONE=1
        ;;
cluster-instance | ci )
	INSTALL_ZEO=1
	POST_ONLY=1
	;;
standalone-instance | si | instance )
        INSTALL_STANDALONE=1
        POST_ONLY=1
        ;;
*)
	echo ""
        echo "usage: install.sh zeo | standalone"
	echo
        echo 'Specify "zeo" for ZEO cluster install, or "standalone" for stand-alone Zope.'
		echo
		echo Will install Zope with Python and Plone at $PLONE_HOME
		echo
		echo Use sudo or su to root if you wish to install as root.
		echo
		echo Edit install.sh to specify alternate install location.
	echo ""
        exit 1
        ;;
esac


if [ $ROOT_INSTALL -eq 1 ]
then
	echo "Root install method chosen"
else
	echo "Rootless install method chosen. Will install for use by system user $USER"
fi

#############################################################
# skip to post install if $POST_ONLY != 0
if [ $POST_ONLY -eq 0 ]
then


##############################################################
# Exit if potential conflict with other install at $PLONE_HOME
if [ -e $PLONE_HOME ]
then
	echo ""
	echo "An existing install was detected at $PLONE_HOME."
	echo "Install aborted"
	exit 1
fi


###############################################
# library need determination
if [ $INSTALL_ZLIB = "auto" ]
then
	# check for zconf.h, zlib.h, libz.[so|a]
	if [ -e /usr/include/zconf.h ] || [ -e /usr/local/include/zconf.h ]
	then
		HAVE_ZCONF=1
		#echo have zconf
	else
		HAVE_ZCONF=0
		#echo no zconf
	fi
        if [ -e /usr/include/zlib.h ] || [ -e /usr/local/include/zlib.h ] 
        then
                HAVE_ZLIB=1
                #echo have zlib
        else
                HAVE_ZLIB=0  
                #echo no zlib
        fi
        if [ -e /usr/lib/libz.so ] || [ -e /usr/local/lib/libz.so ] || \
	   [ -e /usr/lib/libz.dylib ] || [ -e /usr/local/lib/libz.dylib ] || \
	   [ -e /usr/lib/libz.a ] || [ -e /usr/local/lib/libz.a ]
        then
                HAVE_LIBZ=1
                #echo have libz
        else
                HAVE_LIBZ=0
                #echo no libz
        fi
	if [ $HAVE_ZCONF -eq 1 ] && [ $HAVE_ZLIB -eq 1 ] && [ $HAVE_LIBZ -eq 1 ]
	then
		INSTALL_ZLIB=no
		#echo do not install zlib
	fi
	if [ $INSTALL_ZLIB = "auto" ] && [ $ROOT_INSTALL -eq 1 ]
	then
		INSTALL_ZLIB="global"
	fi
	if [ $INSTALL_ZLIB = "auto" ]
	then
		INSTALL_ZLIB="local"
	fi
	echo "zlib installation: $INSTALL_ZLIB"
fi

if [ $INSTALL_JPEG = "auto" ]
then
	# check for jpeglib.h and libjpeg.[so|a]
	if [ -e /usr/include/jpeglib.h ] || [ -e /usr/local/include/jpeglib.h ]
	then
		HAVE_JPEGH=1
	else
		HAVE_JPEGH=0
	fi
	if [ -e /usr/lib/libjpeg.so ] || [ -e /usr/local/lib/libjpeg.so ] || \
	   [ -e /usr/lib/libjpeg.dylib ] || [ -e /usr/local/lib/libjpeg.dylib ] || \
	   [ -e /usr/lib/libjpeg.a ] || [ -e /usr/local/lib/libjpeg.a ]
	then
		HAVE_LIBJPEG=1
	else
		HAVE_LIBJPEG=0
	fi
	if [ $HAVE_JPEGH -eq 1 ] && [ $HAVE_LIBJPEG -eq 1 ]
	then
		INSTALL_JPEG="no"
	fi
	if [ $INSTALL_JPEG = "auto" ] && [ $ROOT_INSTALL -eq 1 ]
	then
		INSTALL_JPEG="global"
	fi
	if [ $INSTALL_JPEG = "auto" ]
	then
		INSTALL_JPEG="local"
	fi
	echo "libjpeg installation: $INSTALL_JPEG"
fi



#############################
# Preflight dependency checks
# Binary path variables may have been filled in by literal paths or
# by 'which'. 'which' negative results may be empty or a message.

# Abort install if no gcc
if [ ! $GCC ] || [ ! -x $GCC ]
then
	echo "Note: gcc is required for the install. Exiting now."
	exit 1
fi

# Abort install if no g++
if [ ! $GPP ] || [ ! -x $GPP ]
then
    echo "Note: g++ is required for the install. Exiting now."
    exit 1
fi

# Abort install if no make
if [ ! $GNU_MAKE ] || [ ! -x $GNU_MAKE ]
then
    echo "Note: make is required for the install. Exiting now."
    exit 1
fi

# Abort install if no tar
if [ ! $GNU_TAR ] || [ ! -x $GNU_TAR ]
then
    echo "Note: gnu tar is required for the install. Exiting now."
    exit 1
fi


#################################
# Install will begin in 5 seconds
echo ""
echo "Installing Plone 3.0.3 at $PLONE_HOME"
sleep 5
echo ""



#######################################
# create plone home
mkdir $PLONE_HOME
if [ ! -x $PLONE_HOME ]   
then
        echo "Unable to create $PLONE_HOME" 
        exit 1
fi
if  [ "X$INSTALL_ZLIB" = "Xlocal" ] || [ "X$INSTALL_JPEG" = "Xlocal" ]
then
	NEED_LOCAL=1
	mkdir $LOCAL_HOME
else
	NEED_LOCAL=0
fi



##################
# build zlib 1.2.3
# Note that, even though we're building static libraries, python
# is going to try to build a shared library for it's own use.
# The "-fPIC" flag is thus required for some platforms.
if [ "X$INSTALL_ZLIB" = "Xglobal" ]
then
	echo "Compiling and installing zlib ..."
	cd $PKG
	$GNU_TAR $TAR_BZIP2_FLAG -xf $ZLIB_TB
	chmod -R 775 $ZLIB_DIR
	cd $ZLIB_DIR
	CFLAGS="-fPIC" ./configure
	$GNU_MAKE test
	$GNU_MAKE install
	cd $PKG
	if [ -d $ZLIB_DIR ]
	then
	    rm -rf $ZLIB_DIR
	fi
elif [ "X$INSTALL_ZLIB" = "Xlocal" ]
then
	echo "Compiling and installing local zlib ..."
	cd $PKG
	$GNU_TAR $TAR_BZIP2_FLAG -xf $ZLIB_TB
	chmod -R 775 $ZLIB_DIR
	cd $ZLIB_DIR
	CFLAGS="-fPIC" ./configure --prefix=$LOCAL_HOME
	$GNU_MAKE test
	$GNU_MAKE install
	cd $PKG
	if [ -d $ZLIB_DIR ]
	then
	    rm -rf $ZLIB_DIR
	fi
	if [ ! -e "$LOCAL_HOME/lib/libz.a" ]
	then
		echo "Install of local libz failed"
		exit 1
	fi
else
	echo "Skipping zlib compile and install"
fi


 
###################
# build libjpeg v6b
if [ "X$INSTALL_JPEG" = "Xglobal" ]
then
	echo "Compiling and installing jpeg system libraries ..."

	# It's not impossible that the /usr/local hierarchy doesn't
	# exist. The libjpeg install will not create it itself.
	# (The zlib install will, but we can't count on it having
	# run, since we've made it an option.)
	if [ ! -e /usr/local ]
	then
		mkdir /usr/local
	fi
	if [ ! -e /usr/local/bin ]
	then
		mkdir /usr/local/bin
	fi
	if [ ! -e /usr/local/include ]
	then
		mkdir /usr/local/include
	fi
	if [ ! -e /usr/local/lib ]
	then
		mkdir /usr/local/lib
	fi
	if [ ! -e /usr/local/man ]
	then
		mkdir /usr/local/man
	fi
	if [ ! -e /usr/local/man/man1 ]
	then
		mkdir /usr/local/man/man1
	fi

	cd $PKG
	$GNU_TAR $TAR_BZIP2_FLAG -xf $JPEG_TB
	chmod -R 775 $JPEG_DIR
	cd $JPEG_DIR
	# Oddities to workaround: on Mac OS X, using the "--enable-static"
	# flag will cause the make to fail. So, we need to manually
	# create and place the static library.
	./configure CFLAGS='-fPIC'
	$GNU_MAKE
	$GNU_MAKE install
	ranlib libjpeg.a
	cp libjpeg.a /usr/local/lib
	cp *.h /usr/local/include
	cd $PKG
	if [ -d $JPEG_DIR ]
	then
	        rm -rf $JPEG_DIR
	fi
elif [ "X$INSTALL_JPEG" = "Xlocal" ]
then
	echo "Compiling and installing jpeg local libraries ..."

	mkdir $LOCAL_HOME/lib
	mkdir $LOCAL_HOME/bin
	mkdir $LOCAL_HOME/include
	mkdir $LOCAL_HOME/man
	mkdir $LOCAL_HOME/man/man1
	
	cd $PKG
	$GNU_TAR $TAR_BZIP2_FLAG -xf $JPEG_TB
	chmod -R 775 $JPEG_DIR
	cd $JPEG_DIR
	# Oddities to workaround: on Mac OS X, using the "--enable-static"
	# flag will cause the make to fail. So, we need to manually
	# create and place the static library.
	./configure CFLAGS='-fPIC' --prefix=$LOCAL_HOME
	$GNU_MAKE
	$GNU_MAKE install
	# --enable-static flag doesn't work on OS X, make sure
	# we get an install anyway
	if [ ! -e "$LOCAL_HOME/lib/libjpeg.a" ]
	then
		ranlib libjpeg.a
		cp libjpeg.a $LOCAL_HOME/lib
		cp *.h $LOCAL_HOME/include
	fi

	if [ ! -e "$LOCAL_HOME/lib/libjpeg.a" ]
	then
		echo "Local install of libjpeg has failed"
		exit 1
	fi

	cd $PKG
	if [ -d $JPEG_DIR ]
	then
	        rm -rf $JPEG_DIR
	fi
else
	echo "Skipping libjpeg compile/install"
fi



######################################
# Build Python (with readline and zlib support)
# note: Install readline before running this script
echo "Installing Python 2.4.4..."
cd $PKG
$GNU_TAR $TAR_BZIP2_FLAG -xf $PYTHON_TB
chmod -R 775 $PYTHON_DIR
cd $PYTHON_DIR
# Look for Leopard
uname -v | grep "Darwin Kernel Version 9" > /dev/null
if [ "$?" = "0" ]; then
	# patch for Leopard setpgrp
	sed -E -e "s|(CPPFLAGS=.+)|\\1 -D__DARWIN_UNIX03|" -i.bak Makefile.pre.in
	# if /opt/local is available, make sure it's included in the component
	# build so that we can get fixed readline lib
    if [ -d /opt/local/include ] && [ -d /opt/local/lib ]; then
        sed -E -e "s|#(add_dir_to_list\(self\.compiler\..+_dirs, '/opt/local/)|\\1|" -i.bak setup.py
    fi
fi
if [ $NEED_LOCAL -eq 1 ]
then
	./configure  \
		--prefix=$PY_HOME \
		--with-readline \
		--with-zlib \
		--disable-tk \
		--with-gcc="$GCC -I$LOCAL_HOME/include" \
		--with-cxx="$GPP -I$LOCAL_HOME/include" \
		LDFLAGS="-L$LOCAL_HOME/lib"
else
	./configure \
		--prefix=$PY_HOME \
		--with-readline \
		--with-zlib \
		--disable-tk \
		--with-gcc="$GCC"
fi
$GNU_MAKE
$GNU_MAKE install
cd $PKG
if [ -d $PYTHON_DIR ]
then
	rm -rf $PYTHON_DIR
fi
if [ ! -x "$PY_HOME/bin/python" ]
then
	echo "Install of Python 2.4.4 has failed."
	exit 1
fi
$PY_HOME/bin/python -c "'test'.encode('zip')"
if [ $? -gt 0 ]
then
	echo "Python zlib support is missing; something went wrong in the zlib or python build."
	exit 1
fi



#########################
# install setuptools
# setuptools is not actually required by Plone 3, but many add ons will
# require it.
echo "Installing setuptools via ez_setup..."
cd $PKG
tar -zxf $SETUP_TB
$PY ./ez_setup.py -l
rm ez_setup.py



#################
# build PIL 1.1.6
echo "Compiling and installing PIL ..."
cd $PKG
$GNU_TAR $TAR_BZIP2_FLAG -xf $PIL_TB
chmod -R 775 $PIL_DIR
cd $PIL_DIR
if [ $NEED_LOCAL -eq 1 ]
then
	mv setup.py setup.py.tmp
	SED_CMD="s|JPEG_ROOT = None|JPEG_ROOT = libinclude(\"${LOCAL_HOME}\")|; s|ZLIB_ROOT = None|ZLIB_ROOT = libinclude(\"${LOCAL_HOME}\")|;"
    cat setup.py.tmp | sed -e "$SED_CMD" > setup.py
fi

# force no build of tk support; this has caused problems
# on some platforms, and Plone doesn't need it.
mv setup.py setup.py.tmp
SED_CMD="s|^    _tkinter = None\s*$|    _tkinter = None\n_tkinter = None|;"
cat setup.py.tmp | sed -e "$SED_CMD" > setup.py

$PY ./setup.py build_ext -i
$PY ./selftest.py
if [ $? -gt 0 ]
then
	echo "PIL tests failed."
	exit 1
fi
$PY ./setup.py install
cd $PKG
if [ -d $PIL_DIR ]
then
	rm -rf $PIL_DIR
fi
if [ ! -x "$SITE_PACKAGES/PIL" ]
then
	echo "Install of PIL  has failed."
	exit 1
fi
$PY_HOME/bin/python -c "import _imaging"
if [ $? -gt 0 ]
then
	echo "Python imaging support is missing; something went wrong in the PIL or python build."
	exit 1
fi


#####################
# install ElementTree
echo "Installing ElementTree ..."
cd $PKG
$GNU_TAR -zxf $ETREE_TB
chmod -R 775 $ETREE_DIR
cd $ETREE_DIR
$PY ./setup.py build
$PY ./setup.py install
cd $PKG
if [ -d $ETREE_DIR ]
then
        rm -rf $ETREE_DIR
fi
$PY_HOME/bin/python -c "import elementtree"
if [ $? -gt 0 ]
then
	echo "Python elementree support is missing; something went wrong in the elementree or python build."
	exit 1
fi



#####################
# install libxml2-python
# This is an optional component
echo "Attempting to install libxml2-python ..."
cd $PKG
$GNU_TAR -zxf $PYLIBXML2_TB
chmod -R 775 $PYLIBXML2_DIR
cd $PYLIBXML2_DIR
$PY ./setup.py install
cd $PKG
if [ -d $PYLIBXML2_DIR ]
then
       rm -rf $PYLIBXML2_DIR
fi
$PY_HOME/bin/python -c "import libxml2"
if [ $? -gt 0 ]
then
	echo "Python libxml2 support is missing; something went wrong in the libxml2 build;"
	echo "probably missing development headers."
	echo "This is an optional component. It's absence will result in a log warning."
fi



#####################
# install openid-python
# This is an optional component
echo "Attempting to install openid-python ..."
cd $PKG
$GNU_TAR $TAR_BZIP2_FLAG -xf $PYOID_TB
chmod -R 775 $PYOID_DIR
cd $PYOID_DIR
$PY ./setup.py install
cd $PKG
if [ -d $PYOID_DIR ]
then
        rm -rf $PYOID_DIR
fi
$PY_HOME/bin/python -c "import openid"
if [ $? -gt 0 ]
then
	echo "Python openid support is missing; something went wrong in the openid build."
	echo "This is an optional component. It's absence will disable Plone OpenID support."
fi



##################
# build Zope 2.10.4
echo "Compiling and installing Zope 2.10.4 ..."
cd $PKG
$GNU_TAR $TAR_BZIP2_FLAG -xf $ZOPE_TB
chmod -R 775 $ZOPE_DIR
cd $ZOPE_DIR
./configure --with-python=$PY --prefix=$PLONE_HOME
$GNU_MAKE
$GNU_MAKE install
cd $PKG
if [ -d $ZOPE_DIR ]
then
	rm -rf $ZOPE_DIR
fi
if [ ! -x $PLONE_HOME/bin/mkzopeinstance.py ]
then
	echo "Can't find Zope's mkzopeinstance.py; something went wrong in Zope build"
	exit 1
fi


#########################################################
# Fix path for Zope command line utils (repozo.py et.al.)
echo "Adding Zope library path to site-packages"
echo "$PLONE_HOME/lib/python" > "$SITE_PACKAGES/zope.pth"



# end of if $POST_ONLY -eq 1
fi



######################
# Postinstall steps
######################


cd $CWD

if [ $ROOT_INSTALL -eq 1 ]
then

	################################################
	# Add user account via platform-specific methods
	# if necessary.

	id plone
	if [ "$?" = "0" ]; then
		echo "User 'plone' already exists. No need to create it."
	else
		echo "Adding user account 'plone' to system ..."
		# Add unprivileged user account via 'useradd', if exists (Linux)
		if [ -e /usr/sbin/useradd ]; then
			/usr/sbin/useradd -s /bin/false plone
		
		# Add unprivileged user account via 'adduser', if exists (*BSD)
		elif [ -e /usr/sbin/adduser ]; then
			/usr/sbin/adduser -f helper_scripts/adduser.txt
		
		# try dscl for Mac OS X
		elif [ -e /usr/bin/dscl ]; then
			UNAME=plone
		        # find or create a $UNAME group
		        dscl . search /groups RecordName $UNAME | grep "($UNAME)" > /dev/null
		        if [ "$?" = "0" ]; then
		                gid=$(dscl . read /groups/$UNAME PrimaryGroupID | cut -d" " -f2 -)
		        else
		                gid="50"
		                dscl . search /groups PrimaryGroupID $gid | grep "($gid)" > /dev/null
		                while [ "$?" = "0" ]; do
		                        if [ "$gid" = "500" ]; then
		                                echo Failed to find available gid below 500.  Exiting.
		                                exit 1
		                        else
		                                gid=$(($gid + 1))
		                                dscl . search /groups PrimaryGroupID $gid | grep "($gid)" > /dev/null
		                        fi
		                done
		                echo Creating group $UNAME with gid $gid via dscl...
		                dscl . -create /groups/$UNAME
		                dscl . -create /groups/$UNAME gid $gid
		        fi
		
		        # find or create a $UNAME user
		        dscl . search /users RecordName $UNAME | grep "($UNAME)" > /dev/null
		        if [ "$?" != "0" ]; then
		                # Add plone user via dscl, with a uid below 500
		                echo Creating plone user
		                uiddef=$gid
		                dscl . search /users UniqueID $uiddef | grep "($uiddef)" > /dev/null
		                while [ "$?" = "0" ]; do
		                        if [ "$uiddef" = "500" ]; then
		                                echo Failed to find available uid below 500.  Exiting.
		                                exit 1
		                        else
		                                uiddef=$(($uiddef + 1))
		                                dscl . search /users UniqueID $uiddef | grep "($uiddef)" > /dev/null
		                        fi
		                done
		                #
		                echo Creating user $UNAME with uid $uiddef via dscl...
		                dscl . -create /users/$UNAME
		                if [ "$?" = "0" ]; then
		                        dscl . -create /users/$UNAME UniqueID $uiddef
		                        dscl . -create /users/$UNAME RealName "Plone Administration"
		                        dscl . -create /users/$UNAME PrimaryGroupID $gid
		                        dscl . -create /users/$UNAME NFSHomeDirectory $PLONE_HOME
		                        dscl . -create /users/$UNAME Password '*'
		                        dscl . -create /users/$UNAME UserShell /usr/bin/false
		                else
		                        echo "Creating user plone failed"
		                        exit 1
		                fi
		        else
		                oldgid=$(dscl . read /users/$UNAME PrimaryGroupID | cut -f2 -d" " -)
		                if [ $oldgid != $gid ]; then
		                        dscl . -create /users/$UNAME PrimaryGroupID $gid
		                fi
		        fi
		
		# Try NetInfo niutil
	elif [ -e /usr/bin/niutil ]; then
			niutil -readprop -t localhost/local /users/plone uid
			if [ "$?" != "0" ]; then
				# Add plone user to NetInfo, with a uid below 500
				echo Creating plone user
				uiddef="50"
				niutil -readprop -t localhost/local /users/uid=$uiddef name
				while [ "$?" = "0" ]; do
					if [ "$uiddef" = "500" ]
					then
						echo Failed to find available uid below 500.  Exiting.
						exit 1
					else
						uiddef=`echo $uiddef + 1 | bc`
						niutil -readprop -t localhost/local /users/uid=$uiddef name
					fi
				done
				#
				echo Creating user plone with uid $uiddef...
				niutil -create  -t localhost/local /users/plone
				if [ "$?" = "0" ]; then
					niutil -createprop -t localhost/local /users/plone realname "Plone Administration"
					niutil -createprop -t localhost/local /users/plone uid $uiddef
					niutil -createprop -t localhost/local /users/plone gid 20
					niutil -createprop -t localhost/local /users/plone home "$PLONE_HOME"
					niutil -createprop -t localhost/local /users/plone name plone
					niutil -createprop -t localhost/local /users/plone passwd '*'
					niutil -createprop -t localhost/local /users/plone shell /usr/bin/false
					niutil -createprop -t localhost/local /users/plone _writers_passwd plone
				else
					echo "Creating user plone failed"
					exit 1
				fi
			fi
		fi
	fi


fi # if $ROOT_INSTALL

cd $CWD


##########################
# Generate random password
echo "Generating random password ..."
PASSWORD_SCRIPT=helper_scripts/generateRandomPassword.py
PASSWORD=`$PY $PASSWORD_SCRIPT`



################################################
# Install the zeocluster or stand-alone instance
if [ $INSTALL_ZEO -eq 1 ]
then
	. helper_scripts/cluster-mode.sh
elif [ $INSTALL_STANDALONE -eq 1 ]
then
        . helper_scripts/standalone-mode.sh
fi


#######################
# Conclude installation
if [ -d $PLONE_HOME ]
	then
	mkdir $RECEIPTS_HOME
	echo "Plone 3.0.3 install completed on" `date` > $RECEIPTS_HOME/installReceipt-3-0.txt
	echo " "
	echo "#####################################################################"
	echo "######################  Installation Complete  ######################"
	echo " "
	cat $PWFILE
	echo " "
	echo "Plone successfully installed at $PLONE_HOME"
	echo "See $PWFILE"
	echo "for password and startup instructions"
	echo " "
	echo "Ask for help on plone-users list or #plone"
	echo "Submit feedback and report errors at http://dev.plone.org/plone"
	echo " "
	echo "This installer was created by Kamal Gill (kamalgill at mac.com)"
	echo "Maintainers for Plone 3 are Kamal Gill and Steve McMahon (steve at dcn.org)"
	echo " "
else
	echo "There were errors during the install.  Please read readme.txt and try again."
	echo "To report errors with the installer, visit http://dev.plone.org/plone"
fi
